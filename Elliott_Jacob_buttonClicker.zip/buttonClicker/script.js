const decide =(el) =>{
    if ( el.innerText === 'Login'){
    el.innerText = 'Logout'
    }
    else (el.innerText = 'Login')
}

