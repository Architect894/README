function increment_inner_text(el){
    el.innerText++
}